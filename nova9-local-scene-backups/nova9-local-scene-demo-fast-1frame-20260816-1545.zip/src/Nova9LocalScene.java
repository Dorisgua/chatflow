import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.List;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Nova 9 local scene understanding.
 *
 * Private-LAN MJPEG -> in-memory recent frames -> localhost llama.cpp -> MiniCPM-V -> text.
 * No frame, scene description, token, or history is written to disk by this program.
 */
public final class Nova9LocalScene {
    private static final int LOCAL_PORT = 17861;
    private static final int MAX_SCENE_FRAMES = 3;
    private static final String MODEL_SHA256 = "6b0c74962c44bc6bf4b655b9b02c13eda9d5a0491543ae976d1ac18e4b7892e2";
    private static final String MMPROJ_SHA256 = "ca931d861d0801d9003e50697cd764721a334107c0e0415a51168ee1938462de";
    private static final String DETAILED_PROMPT = """
            这些图片按时间先后排列，来自同一个第一人称摄像头。请只根据画面中的可见证据，用简洁中文描述主要场景和活动。
            必须严格按三行输出：
            观察：只写能直接看到的人、物体、位置和动作。
            推测：写最可能发生的活动；无法判断时明确写“无法可靠判断”。
            不确定性：指出饮品种类、是否交谈、人物身份等不能仅凭画面确认的内容。
            不要识别人脸或身份，不要推测年龄、健康、宗教、政治、财务等敏感属性，不要编造画面外的信息。
            """;
    private static final String DEMO_PROMPT = """
            这是第一人称摄像头的最新画面。请只用一句不超过35个汉字的自然中文，描述主要场景和最可能正在发生的活动。
            优先说明人物正在做什么；没有人物时，说明主要物体和环境。
            只依据可见证据，不识别人脸或身份，不推断敏感属性，不编造画面外信息。
            不要输出“观察”“推测”“不确定性”等标签，不要分段，不要重复。活动无法判断时，直接描述看得见的场景。
            """;

    private final Path home;
    private final JFrame window = new JFrame("Nova 9 本地场景理解");
    private final JTextField urlField = new JTextField();
    private final JButton startButton = new JButton("启动本地场景理解");
    private final JButton describeButton = new JButton("立即描述一次");
    private final JButton stopButton = new JButton("停止并清除");
    private final JCheckBox demoModeCheck = new JCheckBox("Demo 快速模式", true);
    private final JLabel statusLabel = new JLabel("等待开始：请粘贴手机应用显示的完整地址");
    private final JLabel privacyLabel = new JLabel("MiniCPM-V 只在本机运行；画面和描述不写入文件");
    private final JTextArea descriptionArea = new JTextArea();
    private final ImagePanel imagePanel = new ImagePanel();

    private final FrameStore latestFrame = new FrameStore();
    private final Deque<byte[]> sceneFrames = new ArrayDeque<>();
    private final Object sceneLock = new Object();
    private final AtomicBoolean descriptionBusy = new AtomicBoolean(false);
    private final AtomicLong runGeneration = new AtomicLong(0);
    private final ExecutorService streamExecutor = Executors.newSingleThreadExecutor(named("phone-stream"));
    private final ExecutorService controlExecutor = Executors.newSingleThreadExecutor(named("model-control"));
    private final ExecutorService descriptionExecutor = Executors.newSingleThreadExecutor(named("scene-description"));
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2, named("memory-sampler"));
    private final javax.swing.Timer previewTimer;

    private volatile MjpegClient camera;
    private volatile LocalModelServer modelServer;
    private volatile Future<?> cameraTask;
    private volatile ScheduledFuture<?> sampleTask;
    private volatile ScheduledFuture<?> autoTask;
    private volatile boolean demoMode = true;

    private Nova9LocalScene(Path home) {
        this.home = home;
        buildWindow();
        previewTimer = new javax.swing.Timer(500, e -> updatePreview());
    }

    public static void main(String[] args) {
        Path home = Path.of(System.getProperty("nova9.scene.home", ".")).toAbsolutePath().normalize();
        if (args.length == 1 && "--self-test".equals(args[0])) {
            runSelfTest(home);
            return;
        }
        System.out.println("Java started; creating the local scene window...");
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> error.printStackTrace(System.err));
        SwingUtilities.invokeLater(() -> new Nova9LocalScene(home).show());
    }

    private void buildWindow() {
        window.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        window.setMinimumSize(new Dimension(950, 650));
        window.setSize(1180, 780);
        window.setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(new EmptyBorder(12, 12, 12, 12));
        JPanel top = new JPanel(new BorderLayout(8, 8));
        JLabel label = new JLabel("手机地址：");
        label.setLabelFor(urlField);
        urlField.setToolTipText("手机应用显示的 http://私有IP:端口/?token=完整地址");
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        describeButton.setEnabled(false);
        stopButton.setEnabled(false);
        demoModeCheck.setToolTipText("开启：最新1帧、单句输出；关闭：最近3帧、详细输出");
        buttons.add(demoModeCheck);
        buttons.add(startButton);
        buttons.add(describeButton);
        buttons.add(stopButton);
        top.add(label, BorderLayout.WEST);
        top.add(urlField, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.EAST);

        descriptionArea.setEditable(false);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        descriptionArea.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 22));
        descriptionArea.setMargin(new Insets(12, 12, 12, 12));
        descriptionArea.setText("Demo 快速模式已开启。\n\n程序只分析最新一帧，并用一句话描述场景；画面和结果不会保存到文件。");
        JScrollPane descriptionScroll = new JScrollPane(descriptionArea);
        descriptionScroll.setPreferredSize(new Dimension(370, 100));

        JPanel bottom = new JPanel(new GridLayout(2, 1, 2, 2));
        privacyLabel.setForeground(new Color(20, 105, 55));
        bottom.add(statusLabel);
        bottom.add(privacyLabel);

        root.add(top, BorderLayout.NORTH);
        root.add(imagePanel, BorderLayout.CENTER);
        root.add(descriptionScroll, BorderLayout.EAST);
        root.add(bottom, BorderLayout.SOUTH);
        window.setContentPane(root);

        startButton.addActionListener(e -> start());
        describeButton.addActionListener(e -> requestDescription(true));
        stopButton.addActionListener(e -> stop(true));
        demoModeCheck.addActionListener(e -> {
            demoMode = demoModeCheck.isSelected();
            descriptionArea.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, demoMode ? 22 : 17));
            status(demoMode
                    ? "已切换为 Demo 快速模式：最新1帧、单句描述"
                    : "已切换为详细模式：最近3帧、谨慎分析");
        });
        urlField.addActionListener(e -> start());
        window.addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { shutdown(); }
        });
    }

    private void show() {
        window.setAlwaysOnTop(true);
        window.setVisible(true);
        window.toFront();
        window.requestFocus();
        System.out.println("Local scene window created successfully.");
        javax.swing.Timer release = new javax.swing.Timer(2000, e -> window.setAlwaysOnTop(false));
        release.setRepeats(false);
        release.start();
    }

    private void start() {
        if (camera != null) return;
        final URI streamUri;
        try {
            streamUri = validateAndBuildStreamUri(urlField.getText().trim());
            requireLocalFiles(home);
        } catch (Exception e) {
            showError(safeMessage(e));
            return;
        }

        setRunningUi(true, false);
        long generation = runGeneration.incrementAndGet();
        urlField.setText("地址已读取；安全令牌不会写入文件或日志");
        descriptionArea.setText("正在启动本地 MiniCPM-V。第一次加载可能需要几十秒，请稍候……");
        status("正在连接 Nova 9，并从本地硬盘加载模型……");

        camera = new MjpegClient(streamUri, latestFrame, this::status);
        cameraTask = streamExecutor.submit(camera);
        previewTimer.start();
        sampleTask = scheduler.scheduleWithFixedDelay(this::sampleForScene, 0, 2, TimeUnit.SECONDS);

        controlExecutor.submit(() -> {
            try {
                LocalModelServer server = new LocalModelServer(home);
                modelServer = server;
                server.startAndWait();
                if (runGeneration.get() != generation || camera == null) {
                    server.close();
                    return;
                }
                SwingUtilities.invokeLater(() -> {
                    setRunningUi(true, true);
                    status(demoMode
                            ? "本地 MiniCPM-V 已就绪；Demo 将自动描述最新画面"
                            : "本地 MiniCPM-V 已就绪；将自动描述最近3帧");
                    descriptionArea.setText("模型已就绪，正在收集最近几秒的画面……");
                });
                autoTask = scheduler.scheduleWithFixedDelay(() -> requestDescription(false), 3, 10, TimeUnit.SECONDS);
            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> {
                    if (runGeneration.get() != generation || camera == null) return;
                    showError("本地模型启动失败：" + safeMessage(e));
                    stop(true);
                });
            }
        });
    }

    private void sampleForScene() {
        byte[] raw = latestFrame.copy();
        if (raw == null) return;
        try {
            byte[] prepared = prepareSceneFrame(raw);
            synchronized (sceneLock) {
                sceneFrames.addLast(prepared);
                while (sceneFrames.size() > MAX_SCENE_FRAMES) zero(sceneFrames.removeFirst());
            }
        } catch (IOException e) {
            status("这一帧无法转换，程序会继续接收下一帧");
        } finally {
            zero(raw);
        }
    }

    private void updatePreview() {
        byte[] copy = latestFrame.copy();
        if (copy == null) return;
        try {
            BufferedImage image = ImageIO.read(new ByteArrayInputStream(copy));
            if (image != null) imagePanel.setImage(image);
        } catch (IOException ignored) {
        } finally {
            zero(copy);
        }
    }

    private void requestDescription(boolean manual) {
        long generation = runGeneration.get();
        LocalModelServer server = modelServer;
        if (server == null || !server.isReady()) {
            if (manual) status("模型仍在加载，请稍候");
            return;
        }
        if (!descriptionBusy.compareAndSet(false, true)) {
            if (manual) status("上一轮场景描述尚未完成");
            return;
        }
        boolean quick = demoMode;
        List<byte[]> frames = copySceneFrames(quick ? 1 : MAX_SCENE_FRAMES);
        if (frames.isEmpty()) {
            descriptionBusy.set(false);
            if (manual) status("尚未收到摄像头画面");
            return;
        }
        status(quick
                ? "Demo 正在理解最新画面……"
                : "正在用本地 MiniCPM-V 理解最近 " + frames.size() + " 帧……");
        descriptionExecutor.submit(() -> {
            long started = System.nanoTime();
            try {
                String description = SceneClient.describe(frames, server.apiKey(), quick);
                double seconds = (System.nanoTime() - started) / 1_000_000_000.0;
                SwingUtilities.invokeLater(() -> {
                    if (runGeneration.get() != generation || camera == null) return;
                    descriptionArea.setText(description);
                    status(String.format(Locale.ROOT, "本地场景描述完成，用时 %.1f 秒；结果未保存", seconds));
                });
            } catch (Exception e) {
                if (runGeneration.get() == generation && camera != null)
                    status("场景描述失败，稍后会重试：" + safeMessage(e));
            } finally {
                frames.forEach(Nova9LocalScene::zero);
                descriptionBusy.set(false);
            }
        });
    }

    private List<byte[]> copySceneFrames(int maximum) {
        synchronized (sceneLock) {
            int count = Math.min(Math.max(1, maximum), sceneFrames.size());
            int skip = sceneFrames.size() - count;
            int index = 0;
            List<byte[]> copies = new ArrayList<>(count);
            for (byte[] frame : sceneFrames) {
                if (index++ >= skip) copies.add(Arrays.copyOf(frame, frame.length));
            }
            return copies;
        }
    }

    private void stop(boolean updateUi) {
        runGeneration.incrementAndGet();
        previewTimer.stop();
        cancel(sampleTask); sampleTask = null;
        cancel(autoTask); autoTask = null;
        MjpegClient currentCamera = camera; camera = null;
        if (currentCamera != null) currentCamera.close();
        Future<?> task = cameraTask; cameraTask = null;
        if (task != null) task.cancel(true);
        latestFrame.clear();
        clearSceneFrames();
        LocalModelServer server = modelServer; modelServer = null;
        if (server != null) server.close();
        if (updateUi) {
            imagePanel.setImage(null);
            descriptionArea.setText("已停止。程序已释放画面和描述引用，等待 Java 回收运行内存。\n要重新开始，请再次粘贴手机地址。");
            urlField.setText("");
            setRunningUi(false, false);
            status("已停止；没有生成图片、视频或场景日志文件");
        }
    }

    private void clearSceneFrames() {
        synchronized (sceneLock) {
            while (!sceneFrames.isEmpty()) zero(sceneFrames.removeFirst());
        }
    }

    private void shutdown() {
        stop(false);
        streamExecutor.shutdownNow();
        controlExecutor.shutdownNow();
        descriptionExecutor.shutdownNow();
        scheduler.shutdownNow();
        window.dispose();
        System.exit(0);
    }

    private void setRunningUi(boolean running, boolean modelReady) {
        startButton.setEnabled(!running);
        describeButton.setEnabled(running && modelReady);
        stopButton.setEnabled(running);
        urlField.setEditable(!running);
    }

    private void status(String text) { SwingUtilities.invokeLater(() -> statusLabel.setText(text)); }
    private void showError(String text) {
        status(text);
        JOptionPane.showMessageDialog(window, text, "无法继续", JOptionPane.ERROR_MESSAGE);
    }

    private static void requireLocalFiles(Path home) {
        for (Path path : List.of(
                home.resolve("runtime").resolve("llama-server.exe"),
                home.resolve("models").resolve("MiniCPM-V-4_6-Q4_K_M.gguf"),
                home.resolve("models").resolve("mmproj-model-f16.gguf"))) {
            if (!Files.isRegularFile(path)) throw new IllegalArgumentException("缺少本地文件：" + path.getFileName());
        }
    }

    private static URI validateAndBuildStreamUri(String value) {
        if (value.isBlank()) throw new IllegalArgumentException("请粘贴手机应用显示的完整地址");
        final URI uri;
        try { uri = URI.create(value); }
        catch (Exception e) { throw new IllegalArgumentException("手机地址格式不正确"); }
        if (!"http".equalsIgnoreCase(uri.getScheme())) throw new IllegalArgumentException("只允许 http 局域网地址");
        if (uri.getUserInfo() != null || uri.getFragment() != null) throw new IllegalArgumentException("手机地址包含不允许的部分");
        String host = uri.getHost();
        if (host == null || !isPrivateIpv4(host)) throw new IllegalArgumentException("只允许私有 IPv4 地址，不允许域名或公网地址");
        int port = uri.getPort();
        if (port < 1 || port > 65535) throw new IllegalArgumentException("手机地址中缺少有效端口");
        String token = null;
        if (uri.getRawQuery() != null) {
            for (String part : uri.getRawQuery().split("&")) {
                int at = part.indexOf('=');
                if (at > 0 && "token".equals(part.substring(0, at))) token = part.substring(at + 1);
            }
        }
        if (token == null || !token.matches("[0-9a-fA-F]{32}")) throw new IllegalArgumentException("地址里的32位安全令牌不正确");
        return URI.create("http://" + host + ":" + port + "/stream?token=" + token.toLowerCase(Locale.ROOT));
    }

    private static boolean isPrivateIpv4(String host) {
        String[] parts = host.split("\\.", -1);
        if (parts.length != 4) return false;
        int[] n = new int[4];
        try {
            for (int i = 0; i < 4; i++) {
                if (parts[i].isEmpty() || (parts[i].length() > 1 && parts[i].startsWith("0"))) return false;
                n[i] = Integer.parseInt(parts[i]);
                if (n[i] < 0 || n[i] > 255) return false;
            }
        } catch (NumberFormatException e) { return false; }
        return n[0] == 10 || (n[0] == 172 && n[1] >= 16 && n[1] <= 31) || (n[0] == 192 && n[1] == 168);
    }

    private static final class FrameStore {
        private byte[] data;
        synchronized void replace(byte[] next) { zero(data); data = next; }
        synchronized byte[] copy() { return data == null ? null : Arrays.copyOf(data, data.length); }
        synchronized void clear() { zero(data); data = null; }
    }

    private static final class MjpegClient implements Runnable, AutoCloseable {
        private final URI streamUri;
        private final FrameStore store;
        private final java.util.function.Consumer<String> status;
        private final AtomicBoolean running = new AtomicBoolean(true);
        private volatile HttpURLConnection connection;

        MjpegClient(URI streamUri, FrameStore store, java.util.function.Consumer<String> status) {
            this.streamUri = streamUri; this.store = store; this.status = status;
        }

        @Override public void run() {
            while (running.get() && !Thread.currentThread().isInterrupted()) {
                try { readStream(); }
                catch (Exception e) { if (running.get()) status.accept("手机视频中断，1秒后重试：" + safeMessage(e)); }
                finally {
                    HttpURLConnection c = connection; connection = null;
                    if (c != null) c.disconnect();
                }
                if (running.get()) try { Thread.sleep(1000); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            }
        }

        private void readStream() throws IOException {
            HttpURLConnection c = (HttpURLConnection) streamUri.toURL().openConnection(Proxy.NO_PROXY);
            connection = c;
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(4000); c.setReadTimeout(7000); c.setUseCaches(false);
            c.setRequestProperty("Accept", "multipart/x-mixed-replace");
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("手机返回 HTTP " + code);
            String type = c.getContentType();
            if (type == null || !type.toLowerCase(Locale.ROOT).contains("multipart/")) throw new IOException("手机返回的不是 MJPEG 视频流");
            status.accept("Nova 9 已连接；最近画面只保存在运行内存中");
            try (InputStream in = new BufferedInputStream(c.getInputStream(), 64 * 1024)) {
                while (running.get()) {
                    String line = readAsciiLine(in, 2048);
                    if (line == null) throw new EOFException("视频流结束");
                    if (!line.startsWith("--")) continue;
                    int length = -1;
                    while (true) {
                        line = readAsciiLine(in, 2048);
                        if (line == null) throw new EOFException("画面头部不完整");
                        if (line.isEmpty()) break;
                        int colon = line.indexOf(':');
                        if (colon > 0 && "content-length".equalsIgnoreCase(line.substring(0, colon).trim()))
                            length = Integer.parseInt(line.substring(colon + 1).trim());
                    }
                    if (length < 100 || length > 5_000_000) throw new IOException("画面大小超出安全范围");
                    byte[] frame = in.readNBytes(length);
                    if (frame.length != length) throw new EOFException("画面不完整");
                    store.replace(frame);
                }
            }
        }

        @Override public void close() {
            running.set(false);
            HttpURLConnection c = connection;
            if (c != null) c.disconnect();
        }

        private static String readAsciiLine(InputStream in, int max) throws IOException {
            ByteArrayOutputStream out = new ByteArrayOutputStream(128);
            int previous = -1;
            while (out.size() <= max) {
                int b = in.read();
                if (b < 0) return out.size() == 0 ? null : out.toString(StandardCharsets.US_ASCII);
                if (previous == '\r' && b == '\n') {
                    byte[] bytes = out.toByteArray();
                    return new String(bytes, 0, Math.max(0, bytes.length - 1), StandardCharsets.US_ASCII);
                }
                out.write(b); previous = b;
            }
            throw new IOException("视频流头部过长");
        }
    }

    private static final class LocalModelServer implements AutoCloseable {
        private final Path home;
        private final String apiKey = randomToken();
        private final AtomicBoolean ready = new AtomicBoolean(false);
        private final AtomicReference<String> lastLine = new AtomicReference<>("");
        private volatile Process process;

        LocalModelServer(Path home) { this.home = home; }

        void startAndWait() throws Exception {
            requireLocalFiles(home);
            List<String> command = List.of(
                    home.resolve("runtime").resolve("llama-server.exe").toString(),
                    "-m", home.resolve("models").resolve("MiniCPM-V-4_6-Q4_K_M.gguf").toString(),
                    "--mmproj", home.resolve("models").resolve("mmproj-model-f16.gguf").toString(),
                    "--host", "127.0.0.1", "--port", Integer.toString(LOCAL_PORT),
                    "-c", "4096", "-n", "180", "-t", "4",
                    "--offline", "--log-disable", "--no-webui", "--no-slots");
            ProcessBuilder builder = new ProcessBuilder(command);
            builder.directory(home.resolve("runtime").toFile());
            builder.redirectErrorStream(true);
            builder.environment().put("HF_HUB_OFFLINE", "1");
            builder.environment().put("TRANSFORMERS_OFFLINE", "1");
            builder.environment().put("LLAMA_API_KEY", apiKey);
            process = builder.start();
            Thread reader = new Thread(() -> consume(process.getInputStream()), "llama-output-discarder");
            reader.setDaemon(true); reader.start();
            long deadline = System.nanoTime() + TimeUnit.MINUTES.toNanos(3);
            while (System.nanoTime() < deadline) {
                if (!process.isAlive()) throw new IOException("llama.cpp 已退出：" + sanitizeServerLine(lastLine.get()));
                if (SceneClient.health()) { ready.set(true); return; }
                Thread.sleep(500);
            }
            throw new IOException("模型在3分钟内没有完成加载");
        }

        boolean isReady() { return ready.get() && process != null && process.isAlive(); }
        String apiKey() { return apiKey; }

        private void consume(InputStream input) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) lastLine.set(line);
            } catch (IOException ignored) { }
        }

        @Override public void close() {
            ready.set(false);
            Process p = process; process = null;
            if (p != null) {
                p.destroy();
                try { if (!p.waitFor(3, TimeUnit.SECONDS)) p.destroyForcibly(); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); p.destroyForcibly(); }
            }
        }
    }

    private static final class SceneClient {
        private static final HttpClient CLIENT = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(2)).followRedirects(HttpClient.Redirect.NEVER)
                .proxy(new DirectProxySelector()).build();
        private static final URI HEALTH = URI.create("http://127.0.0.1:" + LOCAL_PORT + "/health");
        private static final URI CHAT = URI.create("http://127.0.0.1:" + LOCAL_PORT + "/v1/chat/completions");
        private static final Pattern CONTENT = Pattern.compile("\\\"content\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"\\\\])*)\\\"");

        static boolean health() {
            try {
                HttpRequest request = HttpRequest.newBuilder(HEALTH).timeout(Duration.ofSeconds(2)).GET().build();
                int code = CLIENT.send(request, HttpResponse.BodyHandlers.discarding()).statusCode();
                return code >= 200 && code < 300;
            } catch (Exception e) { return false; }
        }

        static String describe(List<byte[]> frames, String apiKey, boolean quick) throws Exception {
            StringBuilder body = new StringBuilder(1024 + frames.stream().mapToInt(f -> f.length * 2).sum());
            int maxTokens = quick ? 64 : 180;
            String prompt = quick ? DEMO_PROMPT : DETAILED_PROMPT;
            body.append("{\"model\":\"local\",\"stream\":false,\"temperature\":0.1,\"max_tokens\":").append(maxTokens).append(',')
                    .append("\"chat_template_kwargs\":{\"enable_thinking\":false},\"reasoning_effort\":\"none\",")
                    .append("\"messages\":[{\"role\":\"user\",\"content\":[")
                    .append("{\"type\":\"text\",\"text\":").append(jsonString(prompt)).append('}');
            for (byte[] frame : frames) {
                body.append(",{\"type\":\"image_url\",\"image_url\":{\"url\":\"data:image/jpeg;base64,")
                        .append(Base64.getEncoder().encodeToString(frame)).append("\"}}");
            }
            body.append("]}]} ");
            HttpRequest request = HttpRequest.newBuilder(CHAT).timeout(Duration.ofMinutes(4))
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8)).build();
            HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (response.statusCode() < 200 || response.statusCode() >= 300)
                throw new IOException("本地模型返回 HTTP " + response.statusCode());
            Matcher matcher = CONTENT.matcher(response.body());
            String content = null;
            while (matcher.find()) content = unescapeJson(matcher.group(1));
            if (content == null || content.isBlank()) {
                if (Boolean.getBoolean("nova9.scene.selftest.debug"))
                    System.err.println("SYNTHETIC SELF-TEST RESPONSE: " + response.body());
                throw new IOException("本地模型没有返回文字");
            }
            return quick ? normalizeQuickDescription(content) : content.trim();
        }

        private static String normalizeQuickDescription(String content) {
            String one = content.replaceAll("\\s+", " ").trim()
                    .replaceFirst("^(?:观察|描述|场景)\\s*[：:]\\s*", "");
            for (int i = 0; i < one.length(); i++) {
                if ("。！？!?".indexOf(one.charAt(i)) >= 0) {
                    one = one.substring(0, i + 1);
                    break;
                }
            }
            if (one.length() > 60) one = one.substring(0, 59) + "…";
            return one;
        }
    }

    private static final class DirectProxySelector extends ProxySelector {
        @Override public List<Proxy> select(URI uri) { return List.of(Proxy.NO_PROXY); }
        @Override public void connectFailed(URI uri, SocketAddress sa, IOException ioe) { }
    }

    private static final class ImagePanel extends JPanel {
        private volatile BufferedImage image;
        ImagePanel() { setBackground(new Color(25, 28, 32)); }
        void setImage(BufferedImage next) { image = next; repaint(); }
        @Override protected void paintComponent(Graphics raw) {
            super.paintComponent(raw);
            BufferedImage current = image;
            Graphics2D g = (Graphics2D) raw.create();
            if (current == null) {
                g.setColor(new Color(205, 210, 215));
                g.setFont(g.getFont().deriveFont(18f));
                String text = "最近3帧只保存在内存中";
                FontMetrics fm = g.getFontMetrics();
                g.drawString(text, (getWidth() - fm.stringWidth(text)) / 2, getHeight() / 2);
            } else {
                double scale = Math.min(getWidth() / (double) current.getWidth(), getHeight() / (double) current.getHeight());
                int w = (int) Math.round(current.getWidth() * scale), h = (int) Math.round(current.getHeight() * scale);
                g.drawImage(current, (getWidth() - w) / 2, (getHeight() - h) / 2, w, h, null);
            }
            g.dispose();
        }
    }

    private static void runSelfTest(Path home) {
        try {
            System.out.println("Checking official model hashes...");
            requireLocalFiles(home);
            verifySha(home.resolve("models").resolve("MiniCPM-V-4_6-Q4_K_M.gguf"), MODEL_SHA256);
            verifySha(home.resolve("models").resolve("mmproj-model-f16.gguf"), MMPROJ_SHA256);
            validateAndBuildStreamUri("http://192.168.1.8:8787/?token=0123456789abcdef0123456789abcdef");
            try {
                validateAndBuildStreamUri("http://8.8.8.8:8787/?token=0123456789abcdef0123456789abcdef");
                throw new IllegalStateException("公网地址没有被拒绝");
            } catch (IllegalArgumentException expected) { }

            System.out.println("Starting localhost MiniCPM-V for a synthetic-image test...");
            try (LocalModelServer server = new LocalModelServer(home)) {
                server.startAndWait();
                BufferedImage image = new BufferedImage(640, 480, BufferedImage.TYPE_INT_RGB);
                Graphics2D g = image.createGraphics();
                g.setColor(new Color(245, 240, 225)); g.fillRect(0, 0, 640, 480);
                g.setColor(new Color(80, 120, 200)); g.fillRect(170, 210, 300, 25);
                g.setColor(Color.WHITE); g.fillOval(270, 150, 100, 90);
                g.setColor(Color.DARK_GRAY); g.drawOval(270, 150, 100, 90); g.dispose();
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                ImageIO.write(image, "jpg", bytes);
                byte[] jpeg = bytes.toByteArray();
                byte[] prepared = prepareSceneFrame(jpeg);
                zero(jpeg);
                byte[] second = Arrays.copyOf(prepared, prepared.length);
                byte[] third = Arrays.copyOf(prepared, prepared.length);
                long started = System.nanoTime();
                String result = SceneClient.describe(List.of(prepared, second, third), server.apiKey(), false);
                long elapsed = TimeUnit.NANOSECONDS.toSeconds(System.nanoTime() - started);
                zero(prepared); zero(second); zero(third);
                if (result.isBlank()) throw new IllegalStateException("场景模型没有输出");
                System.out.println("Local three-frame result (" + elapsed + " seconds): " + result.replace('\n', ' '));
            }
            System.out.println("SELF-TEST OK: hashes, network guard, localhost server, and MiniCPM-V inference passed.");
        } catch (Exception e) {
            System.err.println("SELF-TEST FAILED: " + safeMessage(e));
            e.printStackTrace(System.err);
            System.exit(1);
        }
    }

    private static void verifySha(Path file, String expected) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(file)) {
            byte[] buffer = new byte[1024 * 1024];
            int read;
            while ((read = in.read(buffer)) >= 0) digest.update(buffer, 0, read);
            zero(buffer);
        }
        String actual = HexFormat.of().formatHex(digest.digest());
        if (!actual.equalsIgnoreCase(expected)) throw new SecurityException("校验失败：" + file.getFileName());
    }

    private static byte[] prepareSceneFrame(byte[] jpeg) throws IOException {
        BufferedImage source = ImageIO.read(new ByteArrayInputStream(jpeg));
        if (source == null) throw new IOException("不是有效 JPEG");
        int maxSide = 448;
        double scale = Math.min(1.0, maxSide / (double)Math.max(source.getWidth(), source.getHeight()));
        int width = Math.max(1, (int)Math.round(source.getWidth() * scale));
        int height = Math.max(1, (int)Math.round(source.getHeight() * scale));
        BufferedImage resized = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics = resized.createGraphics();
        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics.drawImage(source, 0, 0, width, height, null);
        graphics.dispose();
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(16 * 1024, jpeg.length / 2));
        if (!ImageIO.write(resized, "jpg", out)) throw new IOException("JPEG编码器不可用");
        return out.toByteArray();
    }

    private static String jsonString(String text) {
        StringBuilder out = new StringBuilder(text.length() + 16).append('"');
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            switch (c) {
                case '"' -> out.append("\\\""); case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n"); case '\r' -> out.append("\\r"); case '\t' -> out.append("\\t");
                default -> { if (c < 32) out.append(String.format(Locale.ROOT, "\\u%04x", (int)c)); else out.append(c); }
            }
        }
        return out.append('"').toString();
    }

    private static String unescapeJson(String text) {
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c != '\\' || i + 1 >= text.length()) { out.append(c); continue; }
            char n = text.charAt(++i);
            switch (n) {
                case 'n' -> out.append('\n'); case 'r' -> out.append('\r'); case 't' -> out.append('\t');
                case 'b' -> out.append('\b'); case 'f' -> out.append('\f'); case '"' -> out.append('"');
                case '\\' -> out.append('\\'); case '/' -> out.append('/');
                case 'u' -> {
                    if (i + 4 < text.length()) { out.append((char)Integer.parseInt(text.substring(i + 1, i + 5), 16)); i += 4; }
                    else out.append('u');
                }
                default -> out.append(n);
            }
        }
        return out.toString();
    }

    private static ThreadFactory named(String name) {
        return r -> { Thread t = new Thread(r, name); t.setDaemon(true); return t; };
    }
    private static String randomToken() {
        byte[] bytes = new byte[24];
        new SecureRandom().nextBytes(bytes);
        String token = HexFormat.of().formatHex(bytes);
        zero(bytes);
        return token;
    }
    private static void cancel(Future<?> future) { if (future != null) future.cancel(false); }
    private static void zero(byte[] bytes) { if (bytes != null) Arrays.fill(bytes, (byte)0); }
    private static String sanitizeServerLine(String line) {
        if (line == null || line.isBlank()) return "没有错误信息";
        return line.replaceAll("[A-Za-z]:\\\\[^ ]+", "[本地路径]").replaceAll("https?://\\S+", "[地址已隐藏]");
    }
    private static String safeMessage(Throwable error) {
        String text = error.getMessage();
        if (text == null || text.isBlank()) text = error.getClass().getSimpleName();
        return text.replaceAll("https?://\\S+", "[地址已隐藏]");
    }
}
